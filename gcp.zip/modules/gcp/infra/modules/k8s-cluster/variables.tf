# Variables for GKE Cluster Module

variable "project_id" {
  description = "GCP Project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
}

variable "zone" {
  description = "GCP zone"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
}

#------------------------------------------------------------------------------
# Resource Names
#------------------------------------------------------------------------------
variable "cluster_name" {
  description = "Name of the GKE cluster"
  type        = string
}

variable "node_pool_name" {
  description = "Name of the node pool"
  type        = string
  default     = ""
}

#------------------------------------------------------------------------------
# Network Configuration
#------------------------------------------------------------------------------
variable "network_id" {
  description = "VPC network ID"
  type        = string
}

variable "subnet_id" {
  description = "Subnet ID"
  type        = string
}

variable "pods_range_name" {
  description = "Name of the secondary range for pods"
  type        = string
}

variable "services_range_name" {
  description = "Name of the secondary range for services"
  type        = string
}

#------------------------------------------------------------------------------
# Cluster Configuration
#------------------------------------------------------------------------------
variable "use_autopilot" {
  description = "Use GKE Autopilot mode"
  type        = bool
  default     = false
}

variable "node_count" {
  description = "Initial number of nodes per zone"
  type        = number
  default     = 1
}

variable "min_node_count" {
  description = "Minimum number of nodes per zone"
  type        = number
  default     = 1
}

variable "max_node_count" {
  description = "Maximum number of nodes per zone"
  type        = number
  default     = 10
}

variable "machine_type" {
  description = "Machine type for nodes"
  type        = string
  default     = "e2-standard-4"
}

variable "disk_size_gb" {
  description = "Disk size in GB for nodes"
  type        = number
  default     = 100
}

variable "release_channel" {
  description = "GKE release channel"
  type        = string
  default     = "REGULAR"
}

variable "network_policy_provider" {
  description = "Network policy provider: CALICO (legacy) or DATA_PLANE_V2 (Cilium-based, recommended)"
  type        = string
  default     = "DATA_PLANE_V2"

  validation {
    condition     = contains(["CALICO", "DATA_PLANE_V2"], var.network_policy_provider)
    error_message = "Network policy provider must be CALICO or DATA_PLANE_V2."
  }
}

#------------------------------------------------------------------------------
# Protection
#------------------------------------------------------------------------------
variable "deletion_protection" {
  description = "Enable deletion protection for the GKE cluster"
  type        = bool
  default     = true
}

#------------------------------------------------------------------------------
# Master Authorized Networks
#------------------------------------------------------------------------------
variable "master_authorized_cidrs" {
  description = "External CIDRs permitted to reach the GKE master endpoint. Empty list (default) omits the master_authorized_networks_config block, leaving the master publicly reachable so Terraform-managed Helm/kubectl steps work from any apply host. Production deployments populate this with operator/CI egress CIDRs."
  type = list(object({
    cidr_block   = string
    display_name = string
  }))
  default = []
}

#------------------------------------------------------------------------------
# Labels
#------------------------------------------------------------------------------
variable "labels" {
  description = "Labels to apply to resources"
  type        = map(string)
  default     = {}
}
