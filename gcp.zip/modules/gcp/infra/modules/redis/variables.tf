# Variables for Redis Module

variable "project_id" {
  description = "GCP Project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
}

#------------------------------------------------------------------------------
# Resource Names
#------------------------------------------------------------------------------
variable "instance_name" {
  description = "Redis instance name"
  type        = string
}

#------------------------------------------------------------------------------
# Instance Configuration
#------------------------------------------------------------------------------
variable "memory_size_gb" {
  description = "Redis memory size in GB"
  type        = number
  default     = 5
}

variable "redis_version" {
  description = "Redis version"
  type        = string
  default     = "REDIS_7_2"
}

variable "rdb_snapshot_period" {
  description = "Optional RDB snapshot period for Redis persistence. Set to null to disable persistence."
  type        = string
  default     = null

  validation {
    condition     = var.rdb_snapshot_period == null || contains(["ONE_HOUR", "SIX_HOURS", "TWELVE_HOURS", "TWENTY_FOUR_HOURS"], var.rdb_snapshot_period)
    error_message = "rdb_snapshot_period must be null, ONE_HOUR, SIX_HOURS, TWELVE_HOURS, or TWENTY_FOUR_HOURS."
  }
}

#------------------------------------------------------------------------------
# Network Configuration
#------------------------------------------------------------------------------
variable "network_id" {
  description = "VPC network ID"
  type        = string
}

#------------------------------------------------------------------------------
# High Availability
#------------------------------------------------------------------------------
variable "high_availability" {
  description = "Enable high availability (Standard HA tier)"
  type        = bool
  default     = true
}

variable "prevent_destroy" {
  description = "Prevent accidental Terraform destroy of Redis instance"
  type        = bool
  default     = false
}

variable "maxmemory_policy" {
  description = "Redis maxmemory-policy."
  type        = string
  default     = "allkeys-lru"

  validation {
    condition     = contains(["noeviction", "allkeys-lru", "volatile-lru", "allkeys-random", "volatile-random", "volatile-ttl"], var.maxmemory_policy)
    error_message = "maxmemory_policy must be a Memorystore-supported Redis maxmemory policy."
  }
}

#------------------------------------------------------------------------------
# Labels
#------------------------------------------------------------------------------
variable "labels" {
  description = "Labels to apply to resources"
  type        = map(string)
  default     = {}
}
