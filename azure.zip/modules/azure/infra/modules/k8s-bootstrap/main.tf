# ── Providers ─────────────────────────────────────────────────────────────────
# Credentials are passed in from the root module via variables (not from a local
# kubeconfig) so this module works in CI/CD pipelines without file system access.

provider "kubernetes" {
  host                   = var.host
  client_certificate     = base64decode(var.client_certificate)
  client_key             = base64decode(var.client_key)
  cluster_ca_certificate = base64decode(var.cluster_ca_certificate)
}

provider "helm" {
  kubernetes {
    host                   = var.host
    client_certificate     = base64decode(var.client_certificate)
    client_key             = base64decode(var.client_key)
    cluster_ca_certificate = base64decode(var.cluster_ca_certificate)
  }
}

# ── Namespace ─────────────────────────────────────────────────────────────────
# Dedicated namespace isolates LangSmith workloads from other cluster tenants.
# The workload.identity label is required by the Azure Workload Identity webhook
# to inject OIDC tokens into pods so they can authenticate to Azure Blob Storage.

resource "kubernetes_namespace_v1" "langsmith" {
  metadata {
    name = var.langsmith_namespace
    labels = {
      "app"                         = "langsmith"
      "azure.workload.identity/use" = "true"
    }
  }
}

# ── Service Account (Workload Identity) ───────────────────────────────────────
# langsmith-ksa is used by LangSmith pods and LGP operator deployments.
# The azure.workload.identity/client-id annotation binds it to the managed
# identity that has Storage Blob Data Contributor on the blob account.

resource "kubernetes_service_account_v1" "langsmith" {
  metadata {
    name      = "langsmith-ksa"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
    annotations = {
      "azure.workload.identity/client-id" = var.blob_managed_identity_client_id
    }
  }
}

# ── Resource Quota ────────────────────────────────────────────────────────────
# Caps total CPU/memory/pod count for the namespace. Prevents a runaway LangSmith
# deployment (e.g. KEDA over-scaling) from starving kube-system or other tenants.
# Defaults: 40 CPU req / 80 CPU lim, 80 GiB req / 160 GiB lim, 200 pods.

resource "kubernetes_resource_quota_v1" "langsmith" {
  metadata {
    name      = "langsmith-quota"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  spec {
    hard = {
      "requests.cpu"    = "40"
      "requests.memory" = "80Gi"
      "limits.cpu"      = "80"
      "limits.memory"   = "160Gi"
      pods              = "200"
    }
  }
}

# ── Limit Range ───────────────────────────────────────────────────────────────
# Required companion to the ResourceQuota above: because the quota's `hard` includes
# requests/limits, Kubernetes forces EVERY pod to declare them. Some chart components
# (e.g. the bundled Postgres/Redis StatefulSets for the standalone insights/polly/fleet
# agent features) ship without resource stanzas, so without defaults they're rejected
# with "failed quota: must specify limits.cpu/... for: <container>" and never schedule.
# This LimitRange supplies defaults so those pods inherit sane values and satisfy the quota.
resource "kubernetes_limit_range_v1" "langsmith" {
  metadata {
    name      = "langsmith-defaults"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  spec {
    limit {
      type = "Container"
      default = {
        cpu    = "1"
        memory = "1Gi"
      }
      default_request = {
        cpu    = "100m"
        memory = "256Mi"
      }
    }
  }
}

# ── Network Policy ────────────────────────────────────────────────────────────
# Default-deny blocks all ingress to LangSmith pods unless explicitly allowed.
# This is defense-in-depth: even if a pod is compromised, it cannot receive
# lateral traffic from other namespaces. Egress is unrestricted (external DBs).

resource "kubernetes_network_policy_v1" "langsmith_default_deny" {
  metadata {
    name      = "default-deny-ingress"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  spec {
    pod_selector {}
    policy_types = ["Ingress"]
  }
}

# Namespace the selected ingress controller's data plane runs in. The
# NetworkPolicy below must allow ingress from this namespace, or the controller's
# proxy cannot reach LangSmith pods (default-deny drops it → 503 with ~10s
# connection timeout). AGIC is intentionally excluded: Application Gateway routes
# from its dedicated subnet (an ip_block), not an in-cluster pod namespace.
locals {
  ingress_namespace = lookup({
    "nginx"         = "ingress-nginx"
    "envoy-gateway" = "envoy-gateway-system"
    "istio"         = "istio-system"
    "istio-addon"   = "aks-istio-ingress"
  }, var.ingress_controller, "")
}

# Allows ingress from the selected ingress controller's namespace (external
# traffic via LB) and from within the langsmith namespace itself (inter-service
# calls). The intra-namespace rule is required on its own: without it, backend
# pods cannot call each other (e.g. queue workers calling the internal API).
resource "kubernetes_network_policy_v1" "langsmith_allow_internal" {
  metadata {
    name      = "allow-from-ingress"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  spec {
    pod_selector {}

    # Ingress controller namespace — skipped for controllers that do not run as
    # in-cluster pods (e.g. agic), where ingress_namespace resolves to "".
    dynamic "ingress" {
      for_each = local.ingress_namespace != "" ? [local.ingress_namespace] : []
      content {
        from {
          namespace_selector {
            match_labels = {
              "kubernetes.io/metadata.name" = ingress.value
            }
          }
        }
      }
    }

    ingress {
      from {
        namespace_selector {
          match_labels = {
            "kubernetes.io/metadata.name" = var.langsmith_namespace
          }
        }
      }
    }

    policy_types = ["Ingress"]
  }
}

# ── Kubernetes Secrets (infrastructure dependencies) ──────────────────────────
# These are created here because they depend on Terraform outputs (connection URLs).
# Application-level secrets (api_key_salt, jwt_secret, admin_password) are
# written by helm/scripts/generate-secrets.sh from Azure Key Vault.

# PostgreSQL connection URL injected into the namespace so the Helm chart can
# reference it via existingSecretName. Created here (not by Helm) because the
# URL is a Terraform output — it's only known after the postgres module runs.
resource "kubernetes_secret_v1" "postgres" {
  count = var.use_external_postgres ? 1 : 0

  metadata {
    name      = "langsmith-postgres-secret"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  data = {
    connection_url = var.postgres_connection_url
    # POSTGRES_URI and POSTGRES_PASSWORD are required by the listener's deploy_image
    # task (host.platforms.k8s_operator.database_k8s.add_postgres_uri_secret) to
    # provision per-deployment databases for LangSmith Deployments (Pass 3+).
    POSTGRES_URI      = var.postgres_connection_url
    POSTGRES_PASSWORD = var.postgres_admin_password
  }

  type = "Opaque"
}

# Fleet Postgres connection URL — the dedicated langsmith_fleet database.
# Referenced by the chart via fleet.postgres.external.existingSecretName. Only the
# Postgres secret is created for Fleet: its Redis is the chart's in-cluster bundled
# StatefulSet (Azure Managed Redis can't provide the logical-DB isolation the
# AWS/GCP Fleet uses, and Fleet has no clusterSafeMode knob), so there is no
# langsmith-fleet-redis secret.
resource "kubernetes_secret_v1" "fleet_postgres" {
  count = var.enable_fleet && var.use_external_postgres ? 1 : 0

  metadata {
    name      = "langsmith-fleet-postgres"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  data = {
    postgres_connection_url = var.fleet_postgres_connection_url
  }

  type = "Opaque"
}

# Redis connection URL (rediss://...) injected the same way as the Postgres secret.
# KEDA ScaledObjects also reference this secret to authenticate queue-depth queries.
resource "kubernetes_secret_v1" "redis" {
  count = var.use_external_redis ? 1 : 0

  metadata {
    name      = "langsmith-redis-secret"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  data = {
    connection_url = var.redis_connection_url
  }

  type = "Opaque"
}

# LangSmith license key secret — required for the application to start.
# The Helm chart references this via config.licenseKeySecretName.
resource "kubernetes_secret_v1" "license" {
  count = var.langsmith_license_key != "" ? 1 : 0

  metadata {
    name      = "langsmith-license"
    namespace = kubernetes_namespace_v1.langsmith.metadata[0].name
  }

  data = {
    license_key = var.langsmith_license_key
  }

  type = "Opaque"
}

# ── cert-manager ──────────────────────────────────────────────────────────────
# TLS automation infrastructure. Manages Let's Encrypt certificates.
# ClusterIssuers are applied separately via:
#   bash helm/scripts/apply-cluster-issuers.sh

resource "helm_release" "cert_manager" {
  name             = "cert-manager"
  namespace        = "cert-manager"
  create_namespace = true
  repository       = "https://charts.jetstack.io"
  chart            = "cert-manager"
  version          = var.cert_manager_version
  wait             = true
  wait_for_jobs    = true

  set {
    name  = "installCRDs"
    value = "true"
  }
  set {
    name  = "controller.resources.requests.cpu"
    value = "100m"
  }
  set {
    name  = "controller.resources.requests.memory"
    value = "128Mi"
  }
  set {
    name  = "controller.resources.limits.cpu"
    value = "200m"
  }
  set {
    name  = "controller.resources.limits.memory"
    value = "256Mi"
  }

  # DNS-01 via Azure Workload Identity: annotate the cert-manager service account
  # with the Managed Identity client ID so it can call the Azure DNS API.
  # The federated credential (created in k8s-cluster module) allows the OIDC
  # token exchange that binds the pod to the identity.
  dynamic "set" {
    for_each = var.tls_certificate_source == "dns01" ? [1] : []
    content {
      name  = "podLabels.azure\\.workload\\.identity/use"
      value = "true"
      type  = "string"
    }
  }
  dynamic "set" {
    for_each = var.tls_certificate_source == "dns01" ? [1] : []
    content {
      name  = "serviceAccount.annotations.azure\\.workload\\.identity/client-id"
      value = var.cert_manager_identity_client_id
    }
  }
}

# HTTP-01 ClusterIssuer is NOT created here.
# kubernetes_manifest requires a live API connection during plan, which fails on fresh
# deploy (no cluster exists yet). It is applied by helm/scripts/deploy.sh instead,
# after the cluster is up, via kubectl apply.

# DNS-01 ClusterIssuer — created by Terraform when tls_certificate_source = "dns01".
# Uses Azure DNS + Workload Identity: no static service principal needed.
# cert-manager controller calls the Azure DNS API to create/delete TXT records
# for ACME challenge verification.
resource "kubernetes_manifest" "cluster_issuer_dns01" {
  count = var.tls_certificate_source == "dns01" ? 1 : 0

  manifest = {
    apiVersion = "cert-manager.io/v1"
    kind       = "ClusterIssuer"
    metadata = {
      name = "letsencrypt-prod"
    }
    spec = {
      acme = {
        server = "https://acme-v02.api.letsencrypt.org/directory"
        email  = var.letsencrypt_email
        privateKeySecretRef = {
          name = "letsencrypt-prod-account-key"
        }
        solvers = [{
          dns01 = {
            azureDNS = {
              subscriptionID    = var.subscription_id
              resourceGroupName = var.dns_resource_group_name
              hostedZoneName    = var.dns_zone_name
              environment       = "AzurePublicCloud"
              managedIdentity = {
                clientID = var.cert_manager_identity_client_id
              }
            }
          }
        }]
      }
    }
  }

  depends_on = [helm_release.cert_manager]
}

# ── KEDA ──────────────────────────────────────────────────────────────────────
# Kubernetes Event-Driven Autoscaling. Scales LangSmith queue workers
# based on Redis queue depth.

resource "helm_release" "keda" {
  name             = "keda"
  namespace        = "keda"
  create_namespace = true
  repository       = "https://kedacore.github.io/charts"
  chart            = "keda"
  version          = var.keda_version
  wait             = true
  wait_for_jobs    = true

  set {
    name  = "resources.operator.requests.cpu"
    value = "100m"
  }
  set {
    name  = "resources.operator.requests.memory"
    value = "128Mi"
  }
  set {
    name  = "resources.operator.limits.cpu"
    value = "500m"
  }
  set {
    name  = "resources.operator.limits.memory"
    value = "512Mi"
  }
  set {
    name  = "resources.metricServer.requests.cpu"
    value = "100m"
  }
  set {
    name  = "resources.metricServer.requests.memory"
    value = "128Mi"
  }
  set {
    name  = "resources.metricServer.limits.cpu"
    value = "500m"
  }
  set {
    name  = "resources.metricServer.limits.memory"
    value = "512Mi"
  }
}
